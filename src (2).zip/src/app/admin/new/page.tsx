'use client'
import { useState } from 'react'

export default function NewProduct() {
    const [name, setName] = useState('')
    const [path, setPath] = useState('')
    const [message, setMessage] = useState('')

    async function handleSubmit(e: React.FormEvent) {
        e.preventDefault()
        const res = await fetch('/api/admin/create', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ path: path ? path.split('/') : [], name })
        })
        const data = await res.json()
        if (data.ok) {
            setMessage('Criado com sucesso')
            setName('')
        } else {
            setMessage(data.error || 'Erro')
        }
    }

    return (
        <main className="mx-auto max-w-screen-sm p-4 space-y-4">
            <h1 className="text-xl font-bold">Novo Produto</h1>
            <form onSubmit={handleSubmit} className="space-y-2">
                <div>
                    <label className="block mb-1">Caminho (Categoria/Subcategoria opcional)</label>
                    <input value={path} onChange={e => setPath(e.target.value)} className="w-full border px-2 py-1" placeholder="Categoria/Sub" />
                </div>
                <div>
                    <label className="block mb-1">Nome do Produto</label>
                    <input value={name} onChange={e => setName(e.target.value)} className="w-full border px-2 py-1" required />
                </div>
                <button type="submit" className="px-4 py-2 bg-blue-600 text-white">Criar</button>
            </form>
            {message && <p>{message}</p>}
        </main>
    )
}