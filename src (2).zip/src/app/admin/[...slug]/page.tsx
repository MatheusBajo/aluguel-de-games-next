import { notFound } from 'next/navigation'
import { getItem } from '@/lib/catalog.server'
import EditForm from '@/app/admin/EditForm'

export const dynamic = 'force-dynamic'

export default async function EditPage({ params }: { params: { slug: string[] } }) {
    const slug = params.slug.map(decodeURIComponent)
    const item = await getItem(slug)
    if (!item) notFound()
    return <EditForm slug={slug} item={item} />
}