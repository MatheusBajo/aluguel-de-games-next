import Link from 'next/link'
import { getCatalog } from '@/lib/catalog.server'

export const dynamic = 'force-dynamic'

export default async function AdminHome() {
    const itens = await getCatalog()
    const grupos = itens.reduce<Record<string, typeof itens>>((acc, it) => {
        const cat = it.key.split('/')[0]
        ;(acc[cat] ||= []).push(it)
        return acc
    }, {})

    return (
        <main className="mx-auto max-w-screen-lg p-4 space-y-6">
            <h1 className="text-2xl font-bold">Gerenciar Produtos</h1>
            <Link className="text-blue-600" href="/admin/new">Novo Produto</Link>
            {Object.entries(grupos).map(([cat, items]) => (
                <div key={cat} className="border-t pt-4">
                    <h2 className="text-xl font-semibold mb-2">{cat}</h2>
                    <ul className="space-y-1 pl-4">
                        {items.map((it) => (
                            <li key={it.key}>
                                <Link className="text-blue-600" href={`/admin/${it.key.split('/').map(encodeURIComponent).join('/')}`}>{it.titulo}</Link>
                            </li>
                        ))}
                    </ul>
                </div>
            ))}
        </main>
    )
}