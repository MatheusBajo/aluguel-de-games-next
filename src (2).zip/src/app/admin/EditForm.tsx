'use client'
import { useState } from 'react'
import ReactMarkdown from 'react-markdown'
import type { CatalogItem } from '@/lib/catalog.server'

interface Props {
    slug: string[]
    item: CatalogItem
}

export default function EditForm({ slug, item }: Props) {
    const [titulo, setTitulo] = useState(item.titulo)
    const [descricao, setDescricao] = useState(item.descricao || '')
    const [message, setMessage] = useState('')

    async function handleSave(e: React.FormEvent) {
        e.preventDefault()
        const res = await fetch('/api/admin/update/' + slug.map(encodeURIComponent).join('/'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ titulo, descricao })
        })
        const data = await res.json()
        if (data.ok) setMessage('Salvo')
        else setMessage(data.error || 'Erro')
    }

    return (
        <main className="mx-auto max-w-screen-md p-4 space-y-4">
            <h1 className="text-xl font-bold">Editar Produto</h1>
            <form onSubmit={handleSave} className="space-y-2">
                <div>
                    <label className="block mb-1">T\u00edtulo</label>
                    <input value={titulo} onChange={e => setTitulo(e.target.value)} className="w-full border px-2 py-1" />
                </div>
                <div>
                    <label className="block mb-1">Descri\u00e7\u00e3o (Markdown)</label>
                    <textarea value={descricao} onChange={e => setDescricao(e.target.value)} className="w-full border px-2 py-1 h-40" />
                </div>
                <button type="submit" className="px-4 py-2 bg-blue-600 text-white">Salvar</button>
            </form>
            {message && <p>{message}</p>}
            <h2 className="text-lg font-semibold pt-4">Preview</h2>
            <div className="prose border p-2">
                <ReactMarkdown>{descricao}</ReactMarkdown>
            </div>
        </main>
    )
}