import { NextRequest, NextResponse } from 'next/server'
import { createProduct } from '@/lib/admin.server'

export async function POST(req: NextRequest) {
    const data = await req.json()
    const pathSegments: string[] = data.path || []
    const name: string = data.name
    if (!name) {
        return NextResponse.json({ error: 'Nome obrigat\u00f3rio' }, { status: 400 })
    }
    try {
        await createProduct(pathSegments, name)
        return NextResponse.json({ ok: true })
    } catch (err: any) {
        return NextResponse.json({ error: err.message }, { status: 500 })
    }
}