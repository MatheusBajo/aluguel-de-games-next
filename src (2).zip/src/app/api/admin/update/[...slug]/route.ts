
import { NextRequest, NextResponse } from 'next/server'
import { updateMetadata } from '@/lib/admin.server'

export async function POST(req: NextRequest, { params }: { params: { slug: string[] } }) {
    const data = await req.json()
    const slug = params.slug.map(decodeURIComponent)
    try {
        await updateMetadata(slug, data)
        return NextResponse.json({ ok: true })
    } catch (err: any) {
        return NextResponse.json({ error: err.message }, { status: 500 })
    }
}